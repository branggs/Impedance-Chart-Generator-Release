IMPEDANCE TABLE — First pass v0.1.0

START
Extract this ZIP to a folder, then double-click ImpedanceTable.exe.
Windows 10/11 with .NET Framework 4.8 is required. No Python, Node, installer,
or internet connection is needed to use the application.

USE
1. Enter your PCB part number.
2. Add a row for each distinct impedance/geometry requirement.
3. Enter one layer or several matching layers, e.g. L1, L16.
4. Choose Single Ended or Differential; enter impedance in ohms and width.
5. Differential rows need Pair gap (edge-to-edge between the two traces).
6. Check Coplanar when applicable and enter Ground clr. (trace edge to ground).
7. Click Save board, or Export DXF. Export also saves the board.

Open a board from the Saved boards list to edit it later. Search by part number.
Saving updates the existing record. Renaming its part number keeps its identity.
Duplicate part numbers are blocked without regard to capitalization.
New board starts a separate record. Ctrl+S saves. Unsaved changes prompt before
opening a different board, creating a new board, or closing the application.
Duplicate and Remove operate on the row containing the selected cell.
Changing mil/mm converts the entered dimensions; impedance does not change.
The System/Light/Dark selector controls the Windows-style UI theme.

DRAWING
Columns: Layer, Single Ended, Differential, Trace Width, Pair Gap,
Ground Clearance. Inapplicable values become dashes automatically.
Single-ended coplanar rows have a dashed pair gap but a ground clearance.
The PCB part number and units are called out above the table.
Table line width: 10 mil (0.254 mm).
Nominal text height: 45 mil (1.143 mm); stroke width: 5 mil (0.127 mm).
Text uses an embedded, uppercase single-line drafting alphabet, exported as
stroked polylines so its thickness does not depend on installed CAD fonts.
Consequently it imports as geometry, not editable text objects. Edit your saved
board in the app and export again to change its contents.

ALTIUM FIRST IMPORT CHECK
DXF coordinates are ALWAYS millimeters, regardless of the units displayed in
its value cells. Import at 1:1 with source units set to millimeters.
The drawing has separate GRID_10MIL and TEXT_5MIL layers.
Confirm that the imported grid measures 10 mil wide and text strokes 5 mil.
Inspect how your Altium import route handles polyline widths; that behavior
has not yet been verified in Altium. A sample DXF is in examples.

SAVED DATA
Records are stored per Windows user at:
%LOCALAPPDATA%\LayerStack\ImpedanceTable\Boards
Use Open data folder in the sidebar to find them. Back up this entire folder
or copy it to another PC while the application is closed. Each board is an XML
file named with its internal ID; do not rename those files. Subsequent saves
retain the previous version as .xml.bak. This is a local board catalog, not a
full revision history or cloud sync service. Removing/replacing the EXE does
not remove your saved boards.

FIRST-PASS VALIDATION
The Windows EXE compiled successfully against .NET Framework 4.8 references.
14 core checks passed: storage round trips, updates, rename identity, backups,
corrupt-record reporting, geometry bounds, fixed strokes, required spacing,
invalid numeric values, and long-label layout.
The exported sample passed an independent ezdxf structural audit with zero
errors or fixes; its units and polyline widths were independently checked.
The table preview PNG was rendered from that exported DXF.
The native Windows UI and actual Altium import have NOT been run here.

No impedance solver is included: the entered geometry/impedances are your
specified values. This tool formats them into the fabrication drawing table.
